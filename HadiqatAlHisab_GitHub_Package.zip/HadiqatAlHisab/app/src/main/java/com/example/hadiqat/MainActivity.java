package com.example.hadiqat;

import android.app.Activity;
import android.os.Bundle;
import android.content.Context;
import android.media.AudioManager;
import android.media.ToneGenerator;
import android.media.MediaPlayer;
import android.graphics.Color;
import android.graphics.Typeface;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import android.content.SharedPreferences;
import java.util.*;

public class MainActivity extends Activity {
    final int BG = Color.rgb(239, 249, 232), GREEN = Color.rgb(43, 112, 65);
    final int DARK = Color.rgb(35, 67, 45), GOLD = Color.rgb(238, 174, 48);
    LinearLayout page; SharedPreferences prefs;
    int level = 0, score = 0, questionNo = 0, correct = 0;
    int a, b, answer; String op; boolean answered = false;
    Random random = new Random();
    String[] levels = {"الأرقام من 0 إلى 9", "العدّ حتى 20", "الأعداد حتى 100", "المقارنة والترتيب",
            "الجمع", "الطرح", "الضرب", "القسمة", "تحدّي العمليات"};
    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(GREEN); getWindow().setNavigationBarColor(GREEN);
        prefs = getSharedPreferences("garden_math", MODE_PRIVATE);
        level = Math.min(prefs.getInt("level", 0), levels.length-1);
        score = prefs.getInt("score", 0);
        showHome();
    }
    TextView text(String s, int size, int color) {
        TextView t = new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(color);
        t.setGravity(Gravity.CENTER); t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        t.setPadding(12,12,12,12); return t;
    }
    void base(String title) {
        page = new LinearLayout(this); page.setOrientation(LinearLayout.VERTICAL);
        page.setGravity(Gravity.CENTER_HORIZONTAL); page.setPadding(20,18,20,18); page.setBackgroundColor(BG);
        ScrollView sc = new ScrollView(this); sc.addView(page);
        setContentView(sc);
        TextView head = text("🌳  حديقة الحساب الذكي  🌳", 25, GREEN);
        page.addView(head);
        page.addView(text(title, 19, DARK));
        page.addView(text("🍎     🍊     🍐     🍋     🍇", 30, GREEN));
    }
    Button btn(String label, Runnable action) {
        Button x = new Button(this); x.setText(label); x.setTextSize(18); x.setAllCaps(false);
        x.setTextColor(Color.WHITE); x.setBackgroundTintList(android.content.res.ColorStateList.valueOf(GREEN));
        x.setOnClickListener(v -> action.run()); return x;
    }
    void addButton(String s, Runnable r) {
        Button x = btn(s,r); LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1,-2);
        p.setMargins(0,8,0,8); page.addView(x,p);
    }
    void showHome() {
        base("نتعلّم الحساب خطوةً خطوة");
        page.addView(text("مرحبًا بك في حديقتنا الجميلة!", 21, DARK));
        page.addView(text("اجمع النجوم، وتعلّم الأرقام والعمليات الحسابية مع ثمار الحديقة.",17,DARK));
        page.addView(text("مجموع نقاطك: " + score + " ⭐", 20, GOLD));
        addButton("ابدأ التعلّم", () -> showLevels());
        addButton("متابعة من حيث توقفت", () -> startQuiz());
        page.addView(text("لا صور لأشخاص أو حيوانات أو طيور — عالمنا أشجار وفواكه وطبيعة.",13,GREEN));
    }
    void showLevels() {
        base("اختر المرحلة التعليمية");
        for (int i=0;i<levels.length;i++) {
            final int n=i;
            String status = i<=level ? " ✓" : " 🔒";
            addButton((i+1)+". "+levels[i]+status, () -> {
                if (n <= level) { level=n; questionNo=0; correct=0; startQuiz(); }
                else Toast.makeText(this,"أكمل المرحلة السابقة أولًا",Toast.LENGTH_SHORT).show();
            });
        }
        addButton("العودة للرئيسية", () -> showHome());
    }
    void startQuiz() {
        answered=false; makeQuestion();
        base("المرحلة "+(level+1)+": "+levels[level]);
        page.addView(text("السؤال "+(questionNo+1)+" من 10     |     النقاط: "+score,16,GREEN));
        String visual = visualForQuestion();
        page.addView(text(visual,32,GREEN));
        page.addView(text(questionText(),27,DARK));
        int[] choices = makeChoices();
        for (int choice: choices) addButton(String.valueOf(choice), () -> choose(choice));
        page.addView(text("تذكّر: المحاولة طريق التعلّم!",15,GREEN));
    }
    void makeQuestion() {
        int max = level==0?9:level==1?20:level<=3?100:level==4?20:level==5?30:level==6?12:level==7?10:20;
        if(level==0 || level==1 || level==2) { a=random.nextInt(max+1); b=0; answer=a; op=""; }
        else if(level==3) { a=random.nextInt(50)+1; b=random.nextInt(50)+1; answer=a; op="compare"; }
        else if(level==4) { a=random.nextInt(max)+1; b=random.nextInt(max)+1; answer=a+b; op="+"; }
        else if(level==5) { a=random.nextInt(max)+1; b=random.nextInt(a+1); answer=a-b; op="−"; }
        else if(level==6) { a=random.nextInt(10)+1; b=random.nextInt(10)+1; answer=a*b; op="×"; }
        else if(level==7) { b=random.nextInt(9)+1; answer=random.nextInt(10); a=b*answer; op="÷"; }
        else { int k=random.nextInt(4); if(k==0){a=random.nextInt(20);b=random.nextInt(20);op="+";answer=a+b;}
            else if(k==1){a=random.nextInt(20)+5;b=random.nextInt(a+1);op="−";answer=a-b;}
            else if(k==2){a=random.nextInt(9)+1;b=random.nextInt(9)+1;op="×";answer=a*b;}
            else {b=random.nextInt(9)+1;answer=random.nextInt(10);a=b*answer;op="÷";}}
    }
    String questionText() {
        if(op.equals("compare")) return "أيهما أكبر؟  "+a+" أم "+b+" ؟";
        if(op.equals("")) return "كم عدد الثمار؟";
        return "ما ناتج:  "+a+"  "+op+"  "+b+"  ؟";
    }
    String visualForQuestion() {
        if(level<=2) {
            String[] fruits={"🍎","🍊","🍐","🍋","🍇"};
            String f=fruits[random.nextInt(fruits.length)];
            StringBuilder s=new StringBuilder();
            for(int i=0;i<Math.min(a,20);i++) s.append(f).append(" ");
            if(a==0)s.append("لا توجد ثمار");
            return s.toString();
        }
        if(op.equals("compare")) return "🌳     🍃     🌳";
        return "🍎  +  🍊  +  🍐";
    }
    int[] makeChoices() {
        LinkedHashSet<Integer> set=new LinkedHashSet<>(); set.add(answer);
        while(set.size()<4) {
            int delta=random.nextInt(9)+1;
            int v=answer+(random.nextBoolean()?delta:-delta);
            if(v>=0) set.add(v);
        }
        ArrayList<Integer> list=new ArrayList<>(set); Collections.shuffle(list);
        int[] out=new int[4]; for(int i=0;i<4;i++)out[i]=list.get(i); return out;
    }
    void choose(int selected) {
        if(answered)return;
        if(selected==answer) {
            answered=true; score+=10; correct++;
            prefs.edit().putInt("score",score).apply();
            applause();
            base("أحسنت، ممتاز!");
            page.addView(text("👏  تصفيق حار!  👏",30,GOLD));
            page.addView(text("إجابة صحيحة: "+answer,24,GREEN));
            addButton(questionNo==9?"إنهاء المرحلة":"السؤال التالي", () -> {
                questionNo++;
                if(questionNo>=10) finishLevel(); else startQuiz();
            });
        } else {
            Toast.makeText(this,"غير صحيح، حاول مرة أخرى",Toast.LENGTH_SHORT).show();
            TextView msg=text("غير صحيح، حاول مرة أخرى",20,Color.rgb(170,70,45));
            page.addView(msg);
        }
    }
    void applause() {
        try {
            MediaPlayer player = MediaPlayer.create(this, R.raw.applause);
            if (player != null) {
                player.setOnCompletionListener(mp -> { mp.release(); });
                player.start();
            }
        } catch(Exception ignored) {}
    }
    void finishLevel() {
        if(level<levels.length-1) level++;
        prefs.edit().putInt("level",level).putInt("score",score).apply();
        base("أتممت المرحلة بنجاح!");
        page.addView(text("🌟 أحسنت! لقد أنهيت عشرة أسئلة.",22,GREEN));
        page.addView(text("إجابات صحيحة: "+correct+" من 10",19,DARK));
        page.addView(text("رصيدك الآن: "+score+" نقطة",20,GOLD));
        addButton("المرحلة التالية", () -> { questionNo=0;correct=0;startQuiz(); });
        addButton("قائمة المراحل", () -> showLevels());
        addButton("الرئيسية", () -> showHome());
    }
    @Override public void onBackPressed() { showHome(); }
}
